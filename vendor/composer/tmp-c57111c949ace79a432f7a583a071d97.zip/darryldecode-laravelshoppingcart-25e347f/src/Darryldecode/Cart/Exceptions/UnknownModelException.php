<?php

namespace Darryldecode\Cart\Exceptions;

class UnknownModelException extends \Exception
{ }
