<?php namespace Darryldecode\Cart\Validators;

/**
 * Created by PhpStorm.
 * User: darryl
 * Date: 1/16/2015
 * Time: 11:00 AM
 */

class CartItemValidator extends Validator {

}